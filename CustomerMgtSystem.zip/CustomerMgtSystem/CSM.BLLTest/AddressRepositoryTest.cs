﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace CSM.BLLTest
{
    [TestClass]
    public class AddressRepositoryTest
    {
        [TestMethod]
        public void TestMethod1()
        {

        }
    }
}
