﻿using CMS.BLL;
using CustomerMgtSystem;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSM.BLLTest
{
    [TestClass]
    public class CustomerRepositoryTest
    {
        [TestMethod]
        public void RetrieveExisting()
        {
            //arrange
            var customerRepository = new CustomerRepository();
            var expected = new Customer(1)
            {
                Email = "test@test.co.za",
                FirstName = "Jonh",
                LastName = "Doe",
                AddressList = new List<Address>()
                {
                    new Address()
                    {
                        AddressType = 1,
                        StreetLine1 = "18 Nicol",
                        StreetLine2 = "Bryanstone",
                        Province = "Gauteng",
                        City = "Randburg",
                        Country = "South Africa",
                        PostalCode = 0157
                    },
                     new Address()
                    {
                        AddressType = 2,
                        StreetLine1 = "190 Macao",
                        StreetLine2 = "Sandton",
                        Province = "Gauteng",
                        City = "Bry",
                        Country = "South Africa",
                        PostalCode = 0157
                    }

        }
            };
            //act
            var actual = customerRepository.Retrieve(1);
            //assert
            Assert.AreEqual(expected.CustomerID, actual.CustomerID);
            Assert.AreEqual(expected.FirstName, actual.FirstName);
            Assert.AreEqual(expected.LastName, actual.LastName);
            Assert.AreEqual(expected.Email, actual.Email);
        }
    }
}