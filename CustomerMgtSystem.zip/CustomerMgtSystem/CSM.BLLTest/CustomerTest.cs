﻿using System;
using CustomerMgtSystem;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace CSM.BLLTest
{
    [TestClass]
    public class CustomerTest
    {
        [TestMethod]
        public void FullNameTestValid()
        {
            //--Arrange
            Customer customer = new Customer();
            customer.FirstName = "Teddy";
            customer.LastName = "Duri";
            Customer.instanceCount += 1;

            string expected = "Duri, Teddy";
            //--Act
            string actual = customer.FullName;
            //--Assert
            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void FirstNameEmpty()
        {
            //--Arrange
            Customer customer = new Customer();
            customer.FirstName = "";
            customer.LastName = "Duri";
            Customer.instanceCount += 1;
            string expected = "Duri";
            //--Act
            string actual = customer.FullName;
            //--Assert
            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void LastNameEmpty()
        {
            //--Arrange
            Customer customer = new Customer();
            customer.FirstName = "Teddy";
            customer.LastName = "";
            Customer.instanceCount += 1;

            string expected = "Teddy";
            //--Act
            string actual = customer.FullName;
            //--Assert
            Assert.AreEqual(expected, actual);
        }
        [TestMethod]
        public void ValidateAll()
        {
            //arrange
            var customer = new Customer();
            customer.LastName = "Baggins";
            customer.Email = "test@test.com";

            var expected = true;
            //act
            var actual = customer.Validate();
            //assert
            Assert.AreEqual(expected, actual);

        }

        [TestMethod]
        public void ValidateMissingLastName()
        {
            //arrange
            var customer = new Customer();
            customer.LastName = "";
            customer.Email = "test@test.com";

            var expected = false;
            //act
            var actual = customer.Validate();
            //assert
            Assert.AreEqual(expected, actual);

        }
        [TestMethod]
        public void ValidateMissingEmail()
        {
            //arrange
            var customer = new Customer();
            customer.LastName = "test";
            customer.Email = "";

            var expected = false;
            //act
            var actual = customer.Validate();
            //assert
            Assert.AreEqual(expected, actual);

        }
    }
}
