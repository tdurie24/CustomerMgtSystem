﻿using CMS.BLL;
using CMS.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomerMgtSystem
{
    public class Order : EntityBase, ILoggable
    {
        public Order()
        {

        }
        public Order(int OrderId)
        {
            this.OrderID = OrderId;
        }
        public int OrderID { get; private set; }
        public int CustomerId { get; set; }
        public int ShippingAddressId { get; set; }
        public DateTimeOffset? OrderDate { get; set; }
        public List<OrderItem> orderItems { get; set; }

        public string Log()
        {
            throw new NotImplementedException();
        }

        public Order Retrieve(int id)
        {
            return new Order();
        }

        public List<Order> Retrieve()
        {
            return new List<Order>();
        }

        public bool Save()
        {
            return true;
        }

        public override bool Validate()
        {
            var isValid = true;
            //if (string.IsNullOrWhiteSpace(ShippingAddressId))
            //    isValid = false;
            //if (string.IsNullOrWhiteSpace(Email))
            //    isValid = false;
            return isValid;
        }
    }
}
