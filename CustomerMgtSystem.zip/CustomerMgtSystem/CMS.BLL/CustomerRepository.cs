﻿using CustomerMgtSystem;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.BLL
{
   public class CustomerRepository
    {
        private AddressRepository addressRepository { get; set; }
        public CustomerRepository()
        {
            addressRepository = new AddressRepository();
        }
        public Customer Retrieve(int id)
        {
            Customer customer = new Customer(id);
            customer.AddressList = addressRepository.RetrieveByCustomerID(id).ToList();
            if(id == 1)
            {
                customer.Email = "test@test.co.za";
                customer.FirstName = "Jonh";
                customer.LastName = "Doe";
            }
            return customer;
        }

        public List<Customer> Retrieve()
        {
            return new List<Customer>();
        }

        public bool Save( Customer customer)
        {
           
            return true;
        }
    }
}
