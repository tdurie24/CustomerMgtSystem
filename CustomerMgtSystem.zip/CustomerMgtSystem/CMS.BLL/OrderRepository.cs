﻿using CustomerMgtSystem;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.BLL
{
   public class OrderRepository
    {
        public Order Retrieve(int id)
        {
            Order order = new Order(id);
            if(id == 1)
            {
                order.OrderDate = new DateTimeOffset(DateTime.Now);
            }
            return order;
        }

        public List<Customer> Retrieve()
        {
            return new List<Customer>();
        }

        public bool Save()
        {
            return true;
        }
    }
}
