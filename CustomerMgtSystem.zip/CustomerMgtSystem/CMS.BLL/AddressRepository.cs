﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.BLL
{
    public class AddressRepository
    {
        public Address Retrieve(int id)
        {
            Address address = new Address(id);
            if (id == 1)
            {
                address.StreetLine1 = "18 Nicol";
                address.StreetLine2 = "Bryanstone";
                address.Province = "Gauteng";
                address.City = "Randburg";
                address.Country = "South Africa";
            }
            return address;
        }

        public IEnumerable<Address> RetrieveByCustomerID(int id)
        {
            var addressList = new List<Address>();
            Address address = new Address(1)
            {
                AddressType = 1,
                StreetLine1 = "12 bang end",
                StreetLine2 = "Ferndale",
                City = "Randbrug",
                Province = "Gateng",
                PostalCode = 1234
            };
            addressList.Add(address);

             address = new Address(2)
            {
                AddressType = 2,
                StreetLine1 = "124 bang end",
                StreetLine2 = "Hobbiton",
                City = "Shire",
                Province = "Modour",
                PostalCode = 0165
            };
            addressList.Add(address);

            return addressList;
        }

        public bool Save()
        {
            return true;
        }
    }
}
