﻿using CustomerMgtSystem;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.BLL
{
  public  class ProductRepository
    {
        public Product Retrieve(int id)
        {
            Product product = new Product(id);
            if (id == 1)
            {
                product.ProductName = "Sunflowers";
                product.Description = "Assorted Size";
                product.CurrentPrice = 15.96M;
            }
            return product;

            
          
        }

        public List<Product> Retrieve()
        {
            return new List<Product>();
        }

        public bool Save()
        {
            return true;
        }
    }
}
