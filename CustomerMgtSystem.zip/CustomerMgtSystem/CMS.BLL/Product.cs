﻿using CMS.BLL;
using CMS.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomerMgtSystem
{
    public class Product : EntityBase, ILoggable
    {
        public Product()
        {

        }
        public Product(int productId)
        {
            this.ProductID = productId;
        }
        public int ProductID { get; private set; }
        private string _ProductName;

        public string ProductName
        {
            get {
           
                return _ProductName.InsertSpaces();
            }
            set {
                
                _ProductName = value;
            }
        }

        public string Description { get; set; }
        public Decimal? CurrentPrice { get; set; }

        public override bool Validate()
        {
            var isValid = true;
            if (string.IsNullOrWhiteSpace(ProductName))
                isValid = false;
            if (CurrentPrice == null)
                isValid = false;
            return isValid;
        }
        public override string ToString()
        {
            return Description ;
        }

      

        public Product Retrieve(int id)
        {
            return new Product();
        }

        public List<Product> Retrieve()
        {
            return new List<Product>();
        }

        public bool Save(Product product)
        {
            var success = true;
            if(product.HasChanges && product.IsValid)
            {
                if (product.Isnew)
                {

                }
                else
                {

                }
            }
            return success;
        }
        public string Log()
        {
            var logString = this.ProductID + ": " + this.ProductName + "Details: " + this.Description + "Status: " + this.EntityState.ToString();
            return logString;
        }

    }
}
