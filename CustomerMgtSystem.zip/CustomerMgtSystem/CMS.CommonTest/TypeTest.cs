﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace CMS.CommonTest
{

    [TestClass]
    public class TypeTest
    {
        [TestMethod]
        public void ValueTypesPassByValue()
        {
            int x = 46;
            incrementNumber(x);

            Assert.AreEqual(46, x);
        }

        private void incrementNumber(int x)
        {
            x += 1;
            x = 0;
        }

        [TestMethod]
        public void StringComparison()
        {
            //arrange
            string name = "hello";
            string name2 = "HELLO";

            bool result = String.Equals(name, name2, System.StringComparison.InvariantCultureIgnoreCase);
            //act

            //assert
            Assert.IsTrue(result);
        }
    }
}
