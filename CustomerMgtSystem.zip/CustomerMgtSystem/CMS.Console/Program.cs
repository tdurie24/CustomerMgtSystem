﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.ConsoleApp
{
    class Program
    {
        public delegate void Test(string Name);
        static void Main(string[] args)
        {
            //Names x = new Names();
            //Test t = new Test(x.WriteNames);

            try
            {
                int x = 1;
                int v = 0;
                Console.Write(x/v);
            }
            catch (Exception ex)
            {

                throw;
            }
            //t("Test");

        }
    }
}
