﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.ConsoleApp
{
    public class Names
    {
        public void WriteNames(string name)
        {
            Console.WriteLine(name);
        }
    }
}
