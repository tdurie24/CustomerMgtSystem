﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Common
{
   public class LoggingService
    {
        public static void WriteToFile(List<ILoggable> changeditems)
        {
            foreach (var item in changeditems)
            {
                //var customerItem = item as Customer
                Console.WriteLine(item. Log());
            }
        }
    }
}
